package widgets;

class ExtensiveWidgetProvider {
}
